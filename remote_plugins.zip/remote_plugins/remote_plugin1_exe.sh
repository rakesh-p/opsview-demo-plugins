#!/bin/sh

echo "OK - Status: 1|status=1"